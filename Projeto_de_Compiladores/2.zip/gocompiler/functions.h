#ifndef FUNCTIONS_H 
#define FUNCTIONS_H

typedef enum { program, decl_list, func_head, func_param, funcbody, func_decl, vardec, varsandstatements, factor, expression, parseargs, statement, funcinvocation, block, blocky }class;

typedef struct node {
    char* symbol;
    class tipo;
    struct node* irmao;
    struct node* filho;
}node;

node* insert_node(class tipo, node* filho, node* irmaovelho, char* symbol);
void mostra_arvore(node* n, int depth);
void mostra_tipo(char* str,int depth);

#endif
