#ifndef HEADER_H
#define HEADER_H

extern int debug;
extern int tree;
extern int linha;
extern int coluna;
extern char* yytext;



#endif

