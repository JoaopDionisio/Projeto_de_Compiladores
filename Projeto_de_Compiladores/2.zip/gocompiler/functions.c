#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "functions.h"

void mostra_tipo(char* str,int depth){

    char *ptr = strtok(str, "\n");
    if(ptr!=NULL){
        for(int i = 0; i < depth; i++)printf(".");
        printf("%s",ptr);
        ptr = strtok(NULL,"\n");
    }
    if(ptr!=NULL){
        printf("\n");
        for(int i = 0; i < depth; i++)printf(".");
        printf("%s",ptr);
    }

}

node* insert_node(class tipo_tmp,node* son, node* irmaovelho, char* symbol){
    node * n = (node*)malloc(sizeof(node));
    if (n == NULL) {
            fprintf(stderr, "Error allocating memory");
            exit(-1);
    }

    node* tmp;
    n->irmao=NULL;
    n->filho=son;

    if(symbol!=NULL){
        n->symbol=(char*)strdup(symbol);
    }
    else{
        n->symbol=NULL;
    }

    n->tipo=tipo_tmp;

    if(irmaovelho==NULL)
            return n;
    for(tmp=irmaovelho; tmp->irmao; tmp=tmp->irmao);
    tmp->irmao=n; //n � o ultimo
    
    return irmaovelho;
}


void mostra_arvore(node* n, int depth){

    if (n->tipo != program) {
        if (n->tipo != decl_list) {
            if(n->tipo != varsandstatements)
                printf("\n");
        }
    }
        
    switch(n->tipo){

        case(program):
            for (int i = 0; i < depth; i++)printf(".");
            printf("Program");
            break;

        case(decl_list): case(varsandstatements):
            depth -= 2;
            break;

        case(func_decl):
            for (int i = 0; i < depth; i++)printf(".");
            printf("FuncDecl");
            break;

        case(func_head):
            for (int i = 0; i < depth; i++)printf(".");
            printf("FuncHeader\n");
            mostra_tipo(n->symbol,depth+2);
            depth+=2;
            printf("\n");
            for(int i = 0; i < depth; i++)printf(".");
            printf("FuncParams");
            break;

        case(func_param):
            for (int i = 0; i < depth; i++)printf(".");
            printf("ParamDecl\n");
            mostra_tipo(n->symbol,depth+2);
            break;

        case(funcbody):
            for (int i = 0; i < depth; i++)printf(".");
            printf("FuncBody");
            break;

        case(vardec):
            for (int i = 0; i < depth; i++)printf(".");
            printf("VarDecl\n");
            mostra_tipo(n->symbol,depth+2);
            break;

        case(expression): case(block): case(blocky): case(factor): case(statement):
            for (int i = 0; i < depth; i++)printf(".");
            printf("%s",n->symbol);
            break;

        case(parseargs): case(funcinvocation):
            for (int i = 0; i < depth; i++)printf(".");
            printf("%s",n->symbol);
            depth-=2;
            break;
    }

    if(n->filho!=NULL){

        node *aux = n->filho;

        while (aux != NULL) {
            mostra_arvore(aux, depth + 2);
            aux = aux->irmao;
        }

        free(aux);
    }
}






