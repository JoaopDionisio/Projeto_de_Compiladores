#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include "functions.h"


symbol_table_list* table_list;
h_table *global;
h_table *tableaux;
extern table_element* symtab;
int mpop = 0;

void print_already_defined(node *node, char *token){
    printf("Line %d, column %d: Symbol %s already defined\n", node->line, node->column, token);
}

token *create_token(char* name, int line, int column){

	token *toktmp = (token*)malloc(sizeof(token*));
	toktmp->name = name;
	toktmp->line = line;
	toktmp->column = column;
	return toktmp;
}

h_table *create_table(char *name, int is_defined) {
    h_table *temp = (h_table *)malloc(sizeof(h_table));
    temp->name = name;
    temp->is_defined = is_defined;
    temp->head = NULL;
    temp->last = NULL;
    return temp;

}

l_node *create_table_node(h_table *table) {
    l_node *table_node = (l_node *)malloc(sizeof(l_node));
    table_node->table = table;
    table_node->irmao = NULL;
    return table_node;
}

void add_symbol_table(symbol_table_list *table_list, h_table *table) {
    if(table_list) {
	l_node *temp = create_table_node(table);
	if(table_list->last != NULL) {
	    table_list->last->irmao = temp;
	    table_list->last = table_list->last->irmao;
	} else {
	    table_list->last = temp;
	    table_list->first = table_list->last;
	}
    }
}

symbol_table_list *create_symbol_table_list(void) {
    symbol_table_list *table_list = (symbol_table_list *)malloc(sizeof(symbol_table_list));
    table_list->first = NULL;
    table_list->last = NULL;
    return table_list;
}

int check_program (node * p){
	table_list = create_symbol_table_list();
	add_symbol_table(table_list, create_table("Global",1));
	global = table_list->first->table;
	
	int error_count = 0;

	error_count += check_decl_list(p->filho);
	
	return error_count;
}

int check_used_func(node* tmp2, node* tmp){

	while(tmp){
		if(tmp->tipoclass != 6){
			if(tmp->key != NULL){
				
				if(!strcmp(tmp->key, tmp2->key)){
					return 1;
				}else{
					if(check_used_func(tmp2,tmp->filho)){
						return 1;
					}
				}
			}else{
				if(check_used_func(tmp2,tmp->filho)){
					return 1;
				}
			}
		}
		tmp = tmp->irmao;
	}
	return 0;
}

int check_used (node* tmp2, node* tmp){
	while(tmp){
		if(tmp->filho->tipoclass == 5){
			if(check_used_func(tmp2, tmp->filho)){
				return 1;
			}
		}
		tmp = tmp->irmao;
	}
	
	return 0;
}


int check_decl_list(node *  ivl){
	int error_count = 0;
	
	node* tmp;
	node* tmp2;
	for(tmp = ivl; tmp; tmp = tmp->irmao){
		if(tmp->filho->tipoclass == 5){//verificar se � funcdec
			error_count += check_funcdecl(tmp->filho->filho, 0);
		}else if(tmp->filho->tipoclass == 6){//verificar se � vardec
			for(tmp2 = tmp->filho; tmp2; tmp2 = tmp2->irmao){
				error_count += check_vardec(tmp2);

			}
		}
	}
	
	table_list->last = table_list->first->irmao;
	
	for(tmp = ivl; tmp; tmp = tmp->irmao){
		if(tmp->filho->tipoclass == 5){
			if(tmp->filho->filho->invalid != 1){
				error_count += check_funcdecl(tmp->filho->filho, 1);
			}
		}
	}
	return error_count;
}

void put_hashtable(h_table *table, char *key, char *type, int is_param,int is_func) {
    if(table != NULL) {
	
	table_element *temp = (table_element *)malloc(sizeof(table_element));
	temp->is_func = is_func;
	temp->key = key;
	temp->tipo = type;
	temp->is_param = is_param;
	temp->cur_param_index = 0;
	temp->irmao = NULL;
	if(table->last == NULL) {
	    table->head = temp;
	    table->last = table->head;
	} else {
	    table->last->irmao = temp;
	    table->last = table->last->irmao;
	}
    }
}

void add_parameter(table_element *symbol, char *param, char *key) {
    if(symbol != NULL && symbol->cur_param_index < MAX_PARAM_SIZE) {
    	symbol->optionalkey[symbol->cur_param_index] = key;
	symbol->optional[symbol->cur_param_index++] = param;
    }
}

table_element *get_hashtable(h_table *table, char *key) {
	
    if(table == NULL) {
	return NULL;
    }
    
    table_element *cur = table->head;
  

    while(cur != NULL && strcmp(cur->key, key) != 0) {
	cur = cur->irmao;
    }
    
    if(cur == NULL)return NULL;
    return cur;
}

char lower(char c) {
    return c - 'A' + 'a';
}

void add_params(table_element *symbol, node* n ){
	char* type_spec_param;
	if(n->filho != NULL){
		for(node* tmp = n->filho; tmp; tmp = tmp->irmao){
			char buffer[BUFFER_SIZE];
			sprintf(buffer,"%c%s",lower(tmp->tipo[0]),tmp->tipo+1);
			type_spec_param = strdup(buffer);
			
			
			add_parameter(symbol, type_spec_param, strdup(tmp->key));
			
		}
		
	}
}

char* put_hashtable_and_params(node* iv, int is_func){
	char* type_spec;

	if(get_hashtable(global, iv->key)!= NULL && is_func){
		print_already_defined(iv, iv->key);
		iv->invalid = 1;
	}

	if(iv->tipo != NULL){
		char buffer[BUFFER_SIZE];
		sprintf(buffer,"%c%s",lower(iv->tipo[0]),iv->tipo+1);
		type_spec = strdup(buffer);
	}
	if(iv->tipo == NULL){
		if(iv->filho != NULL){
			put_hashtable(global, iv->key, "none", 0, is_func);
			add_params(get_hashtable(global, iv->key), iv);
			
		}else{
			put_hashtable(global, iv->key, "none", 0, is_func);
		}
	}else{
		if(iv->filho != NULL){
			put_hashtable(global, iv->key, type_spec, 0, is_func);
			add_params(get_hashtable(global, iv->key), iv);
			
		}else{
			put_hashtable(global, iv->key, type_spec, 0, is_func);
		}
	}
	return type_spec;

}

int check_funcdecl(node* iv, int body){
	
	int erro_counter = 0;
	
	if(!body){
		char* type_spec = put_hashtable_and_params(iv,1);
	
		char buffer2[BUFFER_SIZE];
		strcpy(buffer2,"(");
		int first = 1;
	
		for(int i = 0; i < get_hashtable(global, iv->key)->cur_param_index; ++i) {

			if(first != 1){
				strcat(buffer2,",");
			}
		
			first = 0;	
			strcat(buffer2,get_hashtable(global, iv->key)->optional[i]);    		
		}
		strcat(buffer2,")");
		char buffer3[BUFFER_SIZE];
		strcpy(buffer3,"Function ");
		strcat(buffer3,(char*)strdup(iv->key));
		strcat(buffer3,buffer2);
		
			
		add_symbol_table(table_list, create_table(strdup(buffer3),1));
		tableaux = table_list->last->table;
		
		
		if(iv->tipo != NULL){
			put_hashtable(tableaux, "return", type_spec , 0,0);    
		}else{
			put_hashtable(tableaux, "return", "none" , 0,0);    
		}
		
		for(int i = 0; i < get_hashtable(global, iv->key)->cur_param_index; ++i) {
			put_hashtable(tableaux, get_hashtable(global, iv->key)->optionalkey[i], get_hashtable(global, iv->key)->optional[i] , 1,0);  
		}
		
		
	}
	if(body){
		
		tableaux = table_list->last->table;
		char buffer[BUFFER_SIZE];
		for(node* tmp = iv->irmao->filho; tmp; tmp = tmp->irmao){
	
		
			if(tmp->filho->tipoclass == 6){//se for vardec
	
				for(node* tmp2 = tmp->filho; tmp2; tmp2 = tmp2->irmao){
					if(!check_used_func(tmp2, iv->irmao->filho)){			//olhaaaaaa paraaaaa aquuiiiii
						print_var_never_used(tmp->filho, tmp2->key);
					}
					if(strcmp(get_type(tmp2,tableaux),"undef")){
						print_already_defined(tmp2,tmp2->key);
					}
					sprintf(buffer,"%c%s",lower(tmp2->tipo[0]),tmp2->tipo+1);
					put_hashtable(tableaux, tmp2->key, strdup(buffer) , 0,0);
				}
				
			}else if(tmp->filho->tipoclass == 11||tmp->filho->tipoclass == 13){ 
				
				if(check_expression(tmp->filho, tableaux)){
					erro_counter = 1;
				}
	
			}
		}
		if(table_list->last->irmao)table_list->last = table_list->last->irmao;
		
	}

	
	return erro_counter;
}



int is_number (char* input){
	int len = strlen(input);
	for(int i = 0; i<len;i++){
		if(!isdigit(input[i])){
			return 0;
		}
	}
	return 1;
	
		
}

char* symbolforop(char * operation){
	if(!strcmp(operation, "Mul")){
		return "*";
	}else if(!strcmp(operation, "Div")){
		return "/";
	}else if(!strcmp(operation, "And")){
		return "&&";
	}else if(!strcmp(operation, "Add")){
		return "+";
	}else if(!strcmp(operation, "Sub")){
		return "-";
	}else if(!strcmp(operation, "Assign")){
		return "=";
	}else if(!strcmp(operation, "Gt")){
		return ">";
	}else if(!strcmp(operation, "Ge")){
		return ">=";
	}else if(!strcmp(operation, "Lt")){
		return "<";
	}else if(!strcmp(operation, "Le")){
		return "<=";
	}else if(!strcmp(operation, "Not")){
		return "!";
	}else if(!strcmp(operation, "ParseArgs")){
		return "strconv.Atoi";
	}else if(!strcmp(operation, "Print")){
		return "fmt.Println";
	}
	return "0";
}

int tam_string(char* str){
	int c = 0;
	int len = strlen(str);
	for (int l = 0; l < len; l++){
		if (str[l] != '\0'){
			c++;
		}
	}
	return c;
}

void print_var_never_used(node *node, char *symbol) {
    int columnaux = node->column; 
    while(node){
    	if(!strcmp(node->key, symbol)){
    		break;
    	}
    	columnaux += 3;
    	node = node->irmao;
    }
    printf("Line %d, column %d: Symbol %s declared but never used\n",
	   node->line, columnaux, symbol);
}

void print_symbol_not_found(node *node, char *symbol) {
    printf("Line %d, column %d: Cannot find symbol %s\n",
	   node->line, node->column, symbol);
}

void print_incompatible_types(node *node, char *type1, char *stat) {
    printf("Line %d, column %d: Incompatible type %s in %s statement\n",
	   node->line, node->column +1, type1, stat);
}

void print_cannot_apply_operator_single_type(node *node, char *token, char *type1) {
    printf("Line %d, column %d: Operator %s cannot be applied to type %s\n", node->line, node->column-tam_string(symbolforop(node->key)),
	   token, type1);
}

void print_cannot_apply_operator_double_types(node *node, char *token, char *type1, char *type2) {
    printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",
	   node->line, node->column-tam_string(token), token, type1, type2);
}

int check_expression_minusplusnot(node* n, h_table *tableaux){
	int erro_counter = 0;
	

	if(is_number(n->filho->key)){
		n->filho->annotation = "int";
	}else{
		if(check_expression(n->filho, tableaux)){
			erro_counter = 1;
		}
	}
	if(!strcmp(n->key,"Minus")||!strcmp(n->key,"Plus")){
		n->annotation = n->filho->annotation;
	}
	
	if(!strcmp(n->key,"Not")){
		n->annotation = "bool";
		if(strcmp(n->filho->annotation,"bool")){
			erro_counter = 1;
			print_cannot_apply_operator_single_type(n,symbolforop(n->key),n->filho->annotation);
		}
	}
	return erro_counter;
}

int check_expression_operation(node* n, h_table *tableaux, int parse){
	char * filhoaux;
	char * irmaofilhoaux;
	int minusplusnot = 0;
	int erro_counter = 0;
	
	if(!strcmp(n->filho->key,"Minus")||!strcmp(n->filho->key,"Plus")||!strcmp(n->filho->key,"Not")){
		minusplusnot = 1;
		
		check_expression_minusplusnot(n->filho,tableaux);

		filhoaux = n->filho->filho->annotation;
		
		
	}else{
		
		if(is_number(n->filho->key)){
			n->filho->annotation = "int";
		}else{
			if(check_expression(n->filho, tableaux)){
				
				erro_counter = 1;
			}
			
		}
		
		filhoaux = n->filho->annotation;
	}
	if(parse){
		if(!strcmp(n->filho->filho->key,"Minus")||!strcmp(n->filho->filho->key,"Plus")||!strcmp(n->filho->filho->key,"Not")){
			minusplusnot = 1;
		
			check_expression_minusplusnot(n->filho->filho,tableaux);

			irmaofilhoaux = n->filho->filho->filho->annotation;
		
		}else{
		
			if(is_number(n->filho->filho->key)){
				n->filho->filho->annotation = "int";
			}else{
				if(check_expression(n->filho->filho, tableaux)){
				
					erro_counter = 1;
				}
			}
			irmaofilhoaux = n->filho->filho->annotation;
		}
	
	}else{
		if(!strcmp(n->filho->irmao->key,"Minus")||!strcmp(n->filho->irmao->key,"Plus")||!strcmp(n->filho->irmao->key,"Not")){
			minusplusnot = 1;
		
			check_expression_minusplusnot(n->filho->irmao,tableaux);

			irmaofilhoaux = n->filho->irmao->filho->annotation;
		
		}else{
		
			if(is_number(n->filho->irmao->key)){
				n->filho->irmao->annotation = "int";
			}else{
				if(check_expression(n->filho->irmao, tableaux)){
				
					erro_counter = 1;
				}
			}
			irmaofilhoaux = n->filho->irmao->annotation;
		}
	}
	if(minusplusnot == 0){
		if((strcmp(filhoaux, "bool")||strcmp(irmaofilhoaux, "bool"))&&(!strcmp(n->key, "And")|| !strcmp(n->key, "Or"))){
				print_cannot_apply_operator_double_types(n,symbolforop(n->key),filhoaux,irmaofilhoaux);
				n->annotation = "bool";
				erro_counter = 1;
		}else if(!strcmp(filhoaux,irmaofilhoaux)){
			if(parse && strcmp(filhoaux,"int")){
				print_cannot_apply_operator_double_types(n->filho,symbolforop(n->key),filhoaux,irmaofilhoaux);
				erro_counter = 1;
			}
			if(!strcmp(filhoaux, "bool")&& (!strcmp(n->key, "Add") || !strcmp(n->key, "Sub")|| !strcmp(n->key, "Gt")|| !strcmp(n->key, "Lt")|| !strcmp(n->key, "Ge")|| !strcmp(n->key, "Le"))){
				print_cannot_apply_operator_double_types(n,symbolforop(n->key),filhoaux,irmaofilhoaux);
				n->annotation = "undef";
				erro_counter = 1;
			}else if(!strcmp(filhoaux, "undef")&&!strcmp(irmaofilhoaux, "undef")){
				print_cannot_apply_operator_double_types(n,symbolforop(n->key),filhoaux,irmaofilhoaux);
				n->annotation = "undef";
				erro_counter = 1;
			}else{
				n->annotation = strdup(n->filho->annotation);
				return erro_counter;
			}
		}else{
			if(parse && (strcmp(filhoaux,"int")||strcmp(irmaofilhoaux,"string"))){
				print_cannot_apply_operator_double_types(n->filho,symbolforop(n->key),filhoaux,irmaofilhoaux);
			}else{
				print_cannot_apply_operator_double_types(n,symbolforop(n->key),filhoaux,irmaofilhoaux);
			}
			n->annotation = "undef";
			erro_counter = 1;
		}
	}else{
		if( (!strcmp(n->filho->key,"Not")&& strcmp(filhoaux,"bool"))){
			erro_counter = 1;
			print_cannot_apply_operator_single_type(n,symbolforop(n->key),filhoaux);
		}
		if(!strcmp(n->filho->irmao->key,"Not")&& strcmp(irmaofilhoaux,"bool")){
			erro_counter = 1;
			print_cannot_apply_operator_single_type(n,symbolforop(n->key),irmaofilhoaux);
		}
		n->annotation = strdup(n->filho->annotation);
		return erro_counter;
	}
	return erro_counter;
}

char* get_type(node* n, h_table *tabaux){
	for(table_element* naux = tabaux->head; naux != NULL; naux = naux->irmao){
		if(!strcmp(naux->key, n->key)){
			return naux->tipo;
		}
	}
	return "undef";
}

h_table* get_table_from_key(char* k){
	l_node* lnaux = table_list->first;
	
	while(lnaux){
		if(strstr(lnaux->table->name, k)!= NULL){
			return lnaux->table;
		}
		
		lnaux = lnaux->irmao;
	}
	return NULL;
}

int getnumparams(h_table *taux){
	int i = 0;
	for(table_element* t = taux->head; t; t=t->irmao){
		if(t->is_param){
			i++;
		}
	}
	return i;
}

int check_param(h_table *taux, char* annot, int ordem){
	int o = 0;
	int i = 0;
	
	for(table_element* t = taux->head; t; t=t->irmao){
		
		if(t->is_param){
			o = 1;
			if(!strcmp(annot,"erro")){
				return 1;
			}
			if(i == ordem){
				if(!strcmp(annot,t->tipo)){
					return 0;
				}
			}
			i++;
		}
	}
	if(ordem > i){
		return 1;
	}
	
	if(o == 0)return 0;
	return 1;
}

int check_expression(node* n, h_table *tableaux){
	
	int erro_counter = 0;
	
	char* typeaux;
	if(!strcmp(n->key,"Print")){

		if(n->filho != NULL){
			if(check_expression(n->filho, tableaux)){
				
				erro_counter = 1;
			}
		}
		
		if(!strcmp(n->filho->annotation,"undef")){

			print_incompatible_types(n, n->filho->annotation,symbolforop(n->key));
			
		}
		return erro_counter;
	}
	if(!strcmp(n->key,"ParseArgs")){

		if(n->filho->filho != NULL){
			if(check_expression_operation(n, tableaux,1)){
				
				erro_counter = 1;
			}
			
		}
		n->annotation = "int";
		return erro_counter;
	}
	if(!strcmp(n->key,"Return")){
		
		for(table_element* naux = tableaux->head; naux != NULL; naux = naux->irmao){
			if(!strcmp(naux->key, "return")){
				typeaux = naux->tipo;
			}
		}
		
		if(n->filho != NULL){
		
			if(check_expression(n->filho, tableaux)){
				
				erro_counter = 1;
			}
			if(strcmp(typeaux,n->filho->annotation)){
				char buffer[BUFFER_SIZE];
				sprintf(buffer,"%c%s",lower(n->key[0]),n->key+1);
				print_incompatible_types(n, n->filho->annotation,strdup(buffer));
				erro_counter = 1;
			}	
		}
	
		return erro_counter;
	}
	
	if(!strcmp(n->key,"Block")){

		for(node* tmp = n->filho; tmp; tmp = tmp->irmao){
			if(tmp != NULL){
				if(check_expression(tmp, tableaux)){
					
					erro_counter = 1;
				}
			}
		}
		return erro_counter;
	}
	if(!strcmp(n->key,"For")){

		if(check_expression(n->filho, tableaux)){
			erro_counter = 1;
		}
		if(n->filho->irmao != NULL){
			if(strcmp(n->filho->annotation,"bool")){
			
				char buffer[BUFFER_SIZE];
				sprintf(buffer,"%c%s",lower(n->key[0]),n->key+1);
				print_incompatible_types(n, n->filho->annotation,strdup(buffer));
			}
		

			if(check_expression(n->filho->irmao, tableaux)){
				erro_counter = 1;
			}
		}
		return erro_counter;
	}
	if(!strcmp(n->key,"If")){

		if(check_expression(n->filho, tableaux)){
			
			erro_counter = 1;
		}
		
		if(strcmp(n->filho->annotation,"bool")){
			char buffer[BUFFER_SIZE];
			sprintf(buffer,"%c%s",lower(n->key[0]),n->key+1);
			print_incompatible_types(n, n->filho->annotation,strdup(buffer));
		}
		
		for(node* tmp = n->filho->irmao->filho; tmp; tmp = tmp->irmao){
			if(tmp != NULL){
				if(check_expression(tmp, tableaux)){
					
					erro_counter = 1;
				}
				
			}
		}
		if(n->filho->irmao->irmao->filho){
			for(node* tmp = n->filho->irmao->irmao->filho; tmp; tmp = tmp->irmao){
				if(tmp != NULL){
					if(check_expression(tmp, tableaux)){
						
						erro_counter = 1;
					}
				}
			}
		}

		return erro_counter;
	}
	if(!strcmp(n->key,"Assign")){ 
		
		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		
		return erro_counter;
	}
	if(!strcmp(n->key,"Or")){
		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		return erro_counter;
	
	}
	if(!strcmp(n->key,"And")){

		if(check_expression_operation(n, tableaux,0)){
			
			erro_counter = 1;
		}
		return erro_counter;
		
	}
	if(!strcmp(n->key,"Lt")){
		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;
	}
	if(!strcmp(n->key,"Gt")){

		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;
	}
	if(!strcmp(n->key,"Eq")){

		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;

	}
	if(!strcmp(n->key,"Ne")){
		if(check_expression_operation(n, tableaux,0)){
			
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;

	}
	if(!strcmp(n->key,"Le")){
		if(check_expression_operation(n, tableaux,0)){
			
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;
	}
	if(!strcmp(n->key,"Ge")){
		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;
	}
	if(!strcmp(n->key,"Add")){
		
		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		
		return erro_counter;
	}
	if(!strcmp(n->key,"Sub")){

		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		return erro_counter;
	}
	if(!strcmp(n->key,"Mul")){

		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		return erro_counter;
		
	}
	if(!strcmp(n->key,"Div")){

		check_expression_operation(n, tableaux,0);
		return erro_counter;
	}
	if(!strcmp(n->key,"Mod")){

		if(check_expression_operation(n, tableaux,0)){
			erro_counter = 1;
		}
		return erro_counter;
		
	}
	if(!strcmp(n->key,"Not")){
		if(check_expression_minusplusnot(n, tableaux)){
			erro_counter = 1;
		}
		n->annotation = "bool";
		return erro_counter;
	}
	if(!strcmp(n->key,"Minus")){
		if(check_expression_minusplusnot(n, tableaux)){
			erro_counter = 1;
		}
		n->annotation = n->filho->annotation;
		return erro_counter;
	}
	if(!strcmp(n->key,"Plus")){
		if(check_expression_minusplusnot(n, tableaux)){
			erro_counter = 1;
		}
		n->annotation = n->filho->annotation;
		return erro_counter;
	}
	if(!strcmp(n->key,"Call")){
	
		int exists = 1;
		int paramwrong = 0;
		typeaux = get_type(n->filho, global);
		
		
		if(!strcmp(typeaux,"undef")){
			n->annotation = typeaux;
			paramwrong = 1;
			exists = 0;
			erro_counter = 1;
		}
		if(strcmp(typeaux,"none"))n->annotation = typeaux;
			
		//se for undef da erro

		if(get_hashtable(global, n->filho->key)!=NULL){
			typeaux = printparams(get_hashtable(global, n->filho->key));
		
			n->filho->annotation = typeaux;
		}
		
		int ordem = 0; 
		
		for(node* tmp = n->filho->filho; tmp; tmp = tmp->irmao){
			
			if(check_expression(tmp, tableaux)){
				
				erro_counter = 1;
			}
			if(exists){
				if(tmp->annotation== NULL){
					paramwrong = 1;
					erro_counter = 1;
				}else if(check_param(get_table_from_key(n->filho->key), tmp->annotation, ordem) && !paramwrong){
					paramwrong = 1;
					erro_counter = 1;
				}
			}
				ordem++;
		}
		if(exists){
			if(ordem < getnumparams(get_table_from_key(n->filho->key))){
				paramwrong = 1;
				erro_counter = 1;
			}
		}
		
		if(paramwrong){
		
			n->annotation = "undef";
			char buffer[BUFFER_SIZE];
			strcpy(buffer,"(");
			int first = 1;
	
			for(node* tmp = n->filho->filho; tmp; tmp = tmp->irmao) {

				if(first != 1){
					strcat(buffer,",");
				}
				first = 0;
				if(tmp->annotation == NULL){
					strcat(buffer,"none"); 
				}else{strcat(buffer,tmp->annotation);  
				}  		
			}
			strcat(buffer,")");
			char buffer2[BUFFER_SIZE];
			sprintf(buffer2,"%s%s",strdup(n->filho->key),buffer);
			print_symbol_not_found(n->filho,buffer2);
		}
		
		return erro_counter;
	}
	if(!strcmp(n->symbol,"IntLit")){

		n->annotation = "int";
		return erro_counter;
		
	}
	if(!strcmp(n->symbol,"RealLit")){

		
		n->annotation = "float32";
		return erro_counter;
	}
	if(!strcmp(n->symbol,"StrLit")){
		n->annotation = "string";
		return erro_counter;
	}
	if(!strcmp(n->symbol,"Id")){
		
		
		typeaux = get_type(n, tableaux);
		if(strcmp(typeaux,"undef")){
			n->annotation = typeaux;
			return erro_counter;
		}else{
			if(get_hashtable(global, n->key)!= NULL){
				
				if(get_hashtable(global, n->key)->is_func){
					print_symbol_not_found(n,n->key);
					erro_counter = 1;
					n->annotation = "undef";
				}else{
					typeaux = get_type(n, global);
					if(strcmp(typeaux,"undef")){
						n->annotation = typeaux;
						return erro_counter;
					}else{
						print_symbol_not_found(n,n->key);
						erro_counter = 1;
					}
				}
			}else{
				n->annotation = "undef";
				print_symbol_not_found(n,n->key);
				erro_counter = 1;
			}
		}
		return erro_counter;
		
	}
	return erro_counter;

}

int check_vardec(node* iv){
	
	

	
	
	
	put_hashtable_and_params(iv,0);
	
	
	
	return check_integer_dec(iv->key, iv);
	
}

int check_integer_dec(char* iid, node * iv){

	table_element* newel = insert_el(iid,integer);
	if(newel == NULL){
		print_already_defined(iv,iid);
		return 1;
	}
	return 0;
}

table_element* insert_el(char* str, basic_type t){
	table_element *newSymbol = (table_element*)malloc(sizeof(table_element));
	table_element *aux;
	table_element* previous;
	
	strcpy(newSymbol->name, str);
	newSymbol->typeenum = t;
	newSymbol->irmao = NULL;


	if(symtab){
		for(aux = symtab; aux; previous = aux, aux = aux->irmao){
			if(strcmp(aux->name,str)==0){
				return NULL;
			}
		}
		previous->irmao = newSymbol;
	}
	else{
		symtab = newSymbol;
	}	
	
	
	return newSymbol;
}

char* printparams(table_element *symbol){
    char* paramaux = (char*)malloc(BUFFER_SIZE);
    if(symbol->is_func)strcpy(paramaux,"(");
    if(symbol->cur_param_index > 0) {
	
	for(int i = 0; i < symbol->cur_param_index; ++i) {
	    if(i) {
		strcat(paramaux,",");
	    }
	    strcat(paramaux,(char*)symbol->optional[i]);
	}
	
    }
    if(symbol->is_func)strcat(paramaux,")");
    return paramaux;
}

void print_symbol(table_element *symbol) {
    printf("%s\t", symbol->key);
    
    if(symbol->is_func){
    	printf("%s",printparams(symbol));
    }

    printf("\t");
    
    printf("%s",symbol->tipo);
    
    printf("%s\n", symbol->is_param ? "\tparam" : "");
}

void print_table(h_table *table) {
    
    if(table != NULL) {
	printf("===== %s Symbol Table =====\n", table->name);
	table_element *cur = table->head;
	while(cur != NULL) {
	    print_symbol(cur);
	    cur = cur->irmao;
	}
	printf("\n");
    }
}

void print_table_list(symbol_table_list *table_list) {
    if(table_list != NULL) {
	l_node *cur = table_list->first;
	while(cur != NULL) {
	    if(cur->table->is_defined) {
		print_table(cur->table);
	    }
	    cur = cur->irmao;
	}
    }
}


void mostra_tipo(node* n,int depth,int mostra){
    if(n->tipo!=NULL && mostra){
        for(int i = 0; i < depth; i++)printf(".");
        printf("%s",n->tipo);
    }
    if(n->key!=NULL){
        if(mostra)printf("\n");
        for(int i = 0; i < depth; i++)printf(".");
        if(n->symbol!= NULL){
            		printf("%s(%s)",n->symbol,n->key);
            	}else{
            		printf("%s",n->key);
            	}
    }
    if(n->tipo!=NULL && !mostra){
    	printf("\n");
        for(int i = 0; i < depth; i++)printf(".");
        printf("%s",n->tipo);
        
    }

}


node* insert_node(class tipo_class,node* son, node* irmaovelho, char* tipotmp, char* key,char* symbol, int numcol, int numlin){
    node * n = (node*)malloc(sizeof(node));
    if (n == NULL) {
            fprintf(stderr, "Error allocating memory");
            exit(-1);
    }

    node* tmp;
    n->irmao=NULL;
    n->filho=son;
    
    if(numcol!=0){
    	n->column = numcol;
    }
    if(numlin!=0){
    	n->line = numlin;
    }
    if(symbol!=NULL){
        n->symbol=(char*)strdup(symbol);
    }else{
        n->symbol=NULL;
    }
    if(tipotmp!=NULL){
        n->tipo=(char*)strdup(tipotmp);
    }else{
        n->tipo=NULL;
    }
    if(key != NULL){
        n->key=(char*)strdup(key);
    }
    else{
        n->key=NULL;
    }

    n->tipoclass=tipo_class;

    if(irmaovelho==NULL)
            return n;
    for(tmp=irmaovelho; tmp->irmao; tmp=tmp->irmao);
    tmp->irmao=n; //n � o ultimo
    
    return irmaovelho;
}


void mostra_arvore(node* n, int depth){

    if (n->tipoclass != program) {
        if (n->tipoclass != decl_list) {
            if(n->tipoclass != varsandstatements)
                printf("\n");
        }
    }
    
    switch(n->tipoclass){

        case(program):
            for (int i = 0; i < depth; i++)printf(".");
            printf("Program");
            break;

        case(decl_list): case(varsandstatements):
            depth -= 2;
            break;

        case(func_decl):
            for (int i = 0; i < depth; i++)printf(".");
            printf("FuncDecl");
            break;

        case(func_head):
            for (int i = 0; i < depth; i++)printf(".");
            printf("FuncHeader\n");
            mostra_tipo(n,depth+2,0);
            depth+=2;
            printf("\n");
            for(int i = 0; i < depth; i++)printf(".");
            printf("FuncParams");
            break;

        case(func_param):
            for (int i = 0; i < depth; i++)printf(".");
            printf("ParamDecl\n");
            mostra_tipo(n,depth+2,1);
            break;

        case(funcbody):
            for (int i = 0; i < depth; i++)printf(".");
            printf("FuncBody");
            break;

        case(vardec):
            for (int i = 0; i < depth; i++)printf(".");
            printf("VarDecl\n");
            mostra_tipo(n,depth+2,1);
            break;

        case(expression): case(block): case(blocky): case(factor): case(statement):
            for (int i = 0; i < depth; i++)printf(".");
            	if(n->symbol!= NULL){
            		printf("%s(%s)",n->symbol,n->key);
            	}else{
            		printf("%s",n->key);
            	}
            	if(n->annotation != NULL){
            		printf(" - %s",n->annotation);
            	}
            break;

        case(parseargs): case(funcinvocation):
            for (int i = 0; i < depth; i++)printf(".");
            if(n->symbol!= NULL){
            		printf("%s(%s)",n->symbol,n->key);
            	}else{
            		printf("%s",n->key);
            	}
            	if(n->annotation != NULL){
            		printf(" - %s",n->annotation);
            	}
            depth-=2;
            break;
    }

    if(n->filho!=NULL){

        node *aux = n->filho;

        while (aux != NULL) {
            mostra_arvore(aux, depth + 2);
            aux = aux->irmao;
        }

        free(aux);
    }
}






