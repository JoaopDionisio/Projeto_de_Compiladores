#ifndef FUNCTIONS_H 
#define FUNCTIONS_H
#define MAX_PARAM_SIZE 128 //standard c max parameter size
#define BUFFER_SIZE 1024

typedef enum { program, decl_list, func_head, func_param, funcbody, func_decl, vardec, varsandstatements, factor, expression, parseargs, statement, funcinvocation, block, blocky }class;

typedef enum{integer, character, doub} basic_type;

typedef struct token {
	int line, column;
	char* name;
}token;

typedef struct table_element {
    int is_func; 
    char name[32];
    basic_type typeenum;
    char *symbol;
    char *tipo;
    char *key; 
    char *optionalkey[MAX_PARAM_SIZE];
    char *optional[MAX_PARAM_SIZE];
    int cur_param_index;
    int is_param;

    struct table_element* irmao;
}table_element;


typedef struct h_table {
    char *name;
    int is_defined;
    struct table_element *head;
    struct table_element *last;
} h_table;

typedef struct symbol_table_list {
    struct l_node *first;
    struct l_node *last;
} symbol_table_list;

typedef struct l_node {
    struct h_table *table;
    struct l_node *irmao;
} l_node; 

typedef struct node {
    int invalid;
    char* symbol;
    char* annotation;
    char* key;
    char* tipo;
    int line;
    int column;				//alterar para tipo e id separados
    class tipoclass;
    struct node* irmao;
    struct node* filho;
}node;

void print_var_never_used(node *node, char *symbol);
token *create_token(char* name, int line, int column);
char* printparams(table_element *symbol);
char* get_type(node* n, h_table *tableaux);
int check_expression_operation(node* n, h_table *tableaux, int parse);
int check_expression(node* n, h_table *tableaux);
char lower(char c);
void add_parameter(table_element *symbol, char *param, char *key);
void print_symbol(table_element *symbol);
void print_table(h_table *table);
void print_table_list(symbol_table_list *table_list);
int check_integer_dec(char* iid, node * iv);
table_element* insert_el(char* str, basic_type t);
int check_program(node* p);
int check_decl_list(node *  ivl);
int check_funcdecl(node* iv, int body);
int check_vardec(node* iv);
node* insert_node(class tipo, node* filho, node* irmaovelho, char* tipotmp, char* key,char* symbol, int numcol, int numlin);
void mostra_arvore(node* n, int depth);
void mostra_tipo(node* n,int depth,int mostra);

#endif
